import React, { useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../store'

export default function NavBar() {
  const { user, token, me, logout } = useAuth()

  useEffect(() => {
    if (token && !user) me()
  }, [token])

  return (
    <div className="nav">
      <Link to="/">Home</Link>
      <Link to="/new">New Post</Link>
      {user ? (
        <>
          <Link to={`/u/${user.username}`}>@{user.username}</Link>
          <button className="btn secondary" onClick={logout}>Logout</button>
        </>
      ) : (
        <>
          <Link to="/login">Login</Link>
          <Link to="/register">Register</Link>
        </>
      )}
    </div>
  )
}
