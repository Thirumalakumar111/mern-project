import React, { useState } from 'react'
import { usePosts, useAuth } from '../store'
import { Link } from 'react-router-dom'

export default function PostCard({ post }) {
  const { like, unlike, comment } = usePosts()
  const { user } = useAuth()
  const [text, setText] = useState('')

  const liked = user && post.likes && post.likes.some(id => id === user.id)

  const handleLike = () => liked ? unlike(post._id) : like(post._id)
  const submitComment = () => {
    if (text.trim()) {
      comment(post._id, text.trim())
      setText('')
    }
  }

  return (
    <div className="card">
      <div className="row" style={{justifyContent:'space-between'}}>
        <div>
          <Link to={`/u/${post.author.username}`} className="badge">@{post.author.username}</Link>
          <div style={{fontSize:'.85rem', color:'#555'}}>{new Date(post.createdAt).toLocaleString()}</div>
        </div>
        <div className="badge">{post.likes?.length || 0} ❤</div>
      </div>
      <div style={{marginTop:'.5rem', whiteSpace:'pre-wrap'}}>{post.text}</div>
      {post.image ? <img className="post-image" src={post.image.startsWith('http') ? post.image : `http://localhost:5000${post.image}`} /> : null}
      <div className="row" style={{marginTop:'.5rem', gap:'.75rem'}}>
        <button className="btn" onClick={handleLike}>{liked ? 'Unlike' : 'Like'}</button>
      </div>
      <div className="space"></div>
      <div>
        <input className="input" placeholder="Write a comment..." value={text} onChange={e => setText(e.target.value)} />
        <button className="btn" onClick={submitComment}>Comment</button>
      </div>
      <div className="space"></div>
      <div>
        {(post.comments || []).map(c => (
          <div key={c._id} className="row" style={{justifyContent:'space-between'}}>
            <div style={{fontSize:'.95rem'}}>{c.text}</div>
            <div className="badge">{new Date(c.createdAt).toLocaleString()}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
