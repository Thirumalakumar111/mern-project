import React, { useState } from 'react'
import { useAuth } from '../store'
import { useNavigate } from 'react-router-dom'

export default function Register() {
  const [name, setName] = useState('')
  const [username, setUsername] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const { register } = useAuth()
  const nav = useNavigate()

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    try {
      await register({ name, username, email, password })
      nav('/')
    } catch (e) {
      setError(e?.response?.data?.message || 'Register failed')
    }
  }

  return (
    <div className="container">
      <div className="card">
        <h2>Create account</h2>
        {error && <div className="badge" style={{background:'#fee2e2'}}>{error}</div>}
        <form onSubmit={submit}>
          <input className="input" placeholder="Full name" value={name} onChange={e => setName(e.target.value)} />
          <input className="input" placeholder="Username" value={username} onChange={e => setUsername(e.target.value)} />
          <input className="input" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
          <input className="input" placeholder="Password" type="password" value={password} onChange={e => setPassword(e.target.value)} />
          <button className="btn" type="submit">Register</button>
        </form>
      </div>
    </div>
  )
}
