import React, { useState } from 'react'
import { useAuth } from '../store'
import { useNavigate } from 'react-router-dom'

export default function Login() {
  const [emailOrUsername, setEU] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const { login } = useAuth()
  const nav = useNavigate()

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    try {
      await login({ emailOrUsername, password })
      nav('/')
    } catch (e) {
      setError(e?.response?.data?.message || 'Login failed')
    }
  }

  return (
    <div className="container">
      <div className="card">
        <h2>Login</h2>
        {error && <div className="badge" style={{background:'#fee2e2'}}>{error}</div>}
        <form onSubmit={submit}>
          <input className="input" placeholder="Email or Username" value={emailOrUsername} onChange={e => setEU(e.target.value)} />
          <input className="input" placeholder="Password" type="password" value={password} onChange={e => setPassword(e.target.value)} />
          <button className="btn" type="submit">Login</button>
        </form>
      </div>
    </div>
  )
}
