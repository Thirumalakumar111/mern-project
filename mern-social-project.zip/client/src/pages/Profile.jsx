import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { api } from '../api'
import PostCard from '../components/PostCard'
import { useAuth } from '../store'

export default function Profile() {
  const { username } = useParams()
  const [profile, setProfile] = useState(null)
  const [posts, setPosts] = useState([])
  const [error, setError] = useState('')
  const { user } = useAuth()

  const load = async () => {
    try {
      const { data } = await api.get(`/users/${username}`)
      setProfile(data)
      const { data: feed } = await api.get('/posts/feed') // quick workaround to see user's posts too
      setPosts(feed.filter(p => p.author.username === username))
    } catch (e) {
      setError(e?.response?.data?.message || 'Failed')
    }
  }

  useEffect(() => { load() }, [username])

  const follow = async () => {
    await api.post(`/users/${username}/follow`)
    load()
  }
  const unfollow = async () => {
    await api.post(`/users/${username}/unfollow`)
    load()
  }

  if (error) return <div className="container"><div className="card">{error}</div></div>
  if (!profile) return <div className="container"><div className="card">Loading...</div></div>

  const isMe = user && user.username === username
  const amFollowing = user && profile.followers && profile.followers.some(u => u._id === user.id)

  return (
    <div className="container">
      <div className="card">
        <h2>{profile.name} <span className="badge">@{profile.username}</span></h2>
        <p>{profile.bio || 'No bio yet.'}</p>
        <div className="row" style={{gap:'1rem'}}>
          <span className="badge">{profile.followers?.length || 0} followers</span>
          <span className="badge">{profile.following?.length || 0} following</span>
        </div>
        {!isMe && (
          <div className="space"></div>
        )}
        {!isMe && (amFollowing ?
          <button className="btn secondary" onClick={unfollow}>Unfollow</button> :
          <button className="btn" onClick={follow}>Follow</button>
        )}
      </div>

      <h3 className="container">Posts</h3>
      {posts.map(p => <PostCard key={p._id} post={p} />)}
    </div>
  )
}
