import React, { useEffect } from 'react'
import { usePosts, useAuth } from '../store'
import PostCard from '../components/PostCard'

export default function Feed() {
  const { feed, loadFeed } = usePosts()
  const { token } = useAuth()

  useEffect(() => { if (token) loadFeed() }, [token])

  if (!token) {
    return <div className="container"><div className="card">Please login to see your feed.</div></div>
  }

  return (
    <div className="container">
      {feed.map(p => <PostCard key={p._id} post={p} />)}
    </div>
  )
}
