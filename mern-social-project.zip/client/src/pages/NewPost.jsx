import React, { useState } from 'react'
import { usePosts } from '../store'
import { useNavigate } from 'react-router-dom'

export default function NewPost() {
  const [text, setText] = useState('')
  const [file, setFile] = useState(null)
  const [error, setError] = useState('')
  const { createPost } = usePosts()
  const nav = useNavigate()

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    try {
      await createPost({ text, file })
      nav('/')
    } catch (e) {
      setError(e?.response?.data?.message || 'Failed to post')
    }
  }

  return (
    <div className="container">
      <div className="card">
        <h2>New Post</h2>
        {error && <div className="badge" style={{background:'#fee2e2'}}>{error}</div>}
        <form onSubmit={submit}>
          <textarea className="input" rows="4" placeholder="What's happening?" value={text} onChange={e => setText(e.target.value)} />
          <input type="file" onChange={e => setFile(e.target.files?.[0])} />
          <div className="space"></div>
          <button className="btn" type="submit">Post</button>
        </form>
      </div>
    </div>
  )
}
