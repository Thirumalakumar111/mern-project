import React from 'react'
import { Routes, Route } from 'react-router-dom'
import NavBar from './components/NavBar'
import Feed from './pages/Feed'
import Login from './pages/Login'
import Register from './pages/Register'
import NewPost from './pages/NewPost'
import Profile from './pages/Profile'

export default function App() {
  return (
    <>
      <NavBar />
      <Routes>
        <Route path="/" element={<Feed />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/new" element={<NewPost />} />
        <Route path="/u/:username" element={<Profile />} />
      </Routes>
    </>
  )
}
