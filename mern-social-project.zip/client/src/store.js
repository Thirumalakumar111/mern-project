import { create } from 'zustand'
import { api } from './api'

export const useAuth = create((set, get) => ({
  user: null,
  token: localStorage.getItem('token') || null,
  async login(payload) {
    const { data } = await api.post('/auth/login', payload)
    localStorage.setItem('token', data.token)
    set({ user: data.user, token: data.token })
  },
  async register(payload) {
    const { data } = await api.post('/auth/register', payload)
    localStorage.setItem('token', data.token)
    set({ user: data.user, token: data.token })
  },
  async me() {
    const { data } = await api.get('/auth/me')
    set({ user: data.user })
  },
  logout() {
    localStorage.removeItem('token')
    set({ user: null, token: null })
  }
}))

export const usePosts = create((set, get) => ({
  feed: [],
  async loadFeed() {
    const { data } = await api.get('/posts/feed')
    set({ feed: data })
  },
  async createPost({ text, file }) {
    const form = new FormData()
    form.append('text', text)
    if (file) form.append('image', file)
    const { data } = await api.post('/posts', form, { headers: { 'Content-Type': 'multipart/form-data' } })
    set({ feed: [data, ...get().feed] })
  },
  async like(id) {
    await api.post(`/posts/${id}/like`)
    set({ feed: get().feed.map(p => p._id === id ? { ...p, likes: [...p.likes, 'me-temp'] } : p) })
  },
  async unlike(id) {
    await api.post(`/posts/${id}/unlike`)
    set({ feed: get().feed.map(p => p._id === id ? { ...p, likes: p.likes.slice(0, Math.max(0, p.likes.length - 1)) } : p) })
  },
  async comment(id, text) {
    const { data } = await api.post(`/posts/${id}/comments`, { text })
    set({ feed: get().feed.map(p => p._id === id ? { ...p, comments: [...p.comments, data] } : p) })
  }
}))
