# MERN Social — Client

### Quick Start
1) Copy `.env.example` to `.env` (optional).
2) `npm install`
3) `npm run dev`

### Pages
- `/` — Feed (requires login)
- `/login`, `/register`
- `/new` — Create post (text + optional image)
- `/u/:username` — Profile
