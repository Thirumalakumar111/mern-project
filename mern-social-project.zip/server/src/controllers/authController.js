import jwt from 'jsonwebtoken';
import User from '../models/User.js';

const sign = (id) => jwt.sign({ id }, process.env.JWT_SECRET || 'dev', { expiresIn: '7d' });

export const register = async (req, res) => {
  try {
    const { name, username, email, password } = req.body;
    if (!name || !username || !email || !password) {
      return res.status(400).json({ message: 'All fields required' });
    }
    const exists = await User.findOne({ $or: [{ email }, { username: username.toLowerCase() }] });
    if (exists) return res.status(409).json({ message: 'Email or username already used' });
    const user = await User.create({ name, username, email, password });
    const token = sign(user._id);
    return res.status(201).json({ token, user: { id: user._id, name, username, email } });
  } catch (e) {
    return res.status(500).json({ message: e.message });
  }
};

export const login = async (req, res) => {
  try {
    const { emailOrUsername, password } = req.body;
    const user = await User.findOne({
      $or: [{ email: emailOrUsername.toLowerCase() }, { username: emailOrUsername.toLowerCase() }]
    }).select('+password');
    if (!user) return res.status(400).json({ message: 'Invalid credentials' });
    const ok = await user.comparePassword(password);
    if (!ok) return res.status(400).json({ message: 'Invalid credentials' });
    const token = sign(user._id);
    return res.json({ token, user: { id: user._id, name: user.name, username: user.username, email: user.email } });
  } catch (e) {
    return res.status(500).json({ message: e.message });
  }
};

export const me = async (req, res) => {
  const u = req.user;
  res.json({ user: { id: u._id, name: u.name, username: u.username, email: u.email, bio: u.bio, avatar: u.avatar } });
};

export const logout = async (req, res) => {
  res.json({ message: 'ok' });
};
