import Post from '../models/Post.js';
import User from '../models/User.js';

export const createPost = async (req, res) => {
  try {
    const { text } = req.body;
    if (!text) return res.status(400).json({ message: 'Text is required' });
    const image = req.file ? `/uploads/${req.file.filename}` : '';
    const post = await Post.create({ author: req.user._id, text, image });
    res.status(201).json(post);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
};

export const getPost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id).populate('author', 'username name');
    if (!post) return res.status(404).json({ message: 'Not found' });
    res.json(post);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
};

export const likePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: 'Not found' });
    if (!post.likes.includes(req.user._id)) post.likes.push(req.user._id);
    await post.save();
    res.json({ likes: post.likes.length });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
};

export const unlikePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: 'Not found' });
    post.likes = post.likes.filter(id => id.toString() !== req.user._id.toString());
    await post.save();
    res.json({ likes: post.likes.length });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
};

export const addComment = async (req, res) => {
  try {
    const { text } = req.body;
    if (!text) return res.status(400).json({ message: 'Text required' });
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: 'Not found' });
    post.comments.push({ author: req.user._id, text });
    await post.save();
    res.status(201).json(post.comments[post.comments.length - 1]);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
};

export const feed = async (req, res) => {
  try {
    const me = await User.findById(req.user._id);
    const ids = [me._id, ...me.following];
    const posts = await Post.find({ author: { $in: ids } })
      .sort({ createdAt: -1 })
      .limit(50)
      .populate('author', 'username name avatar');
    res.json(posts);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
};
