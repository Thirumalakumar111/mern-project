import User from '../models/User.js';

export const getProfile = async (req, res) => {
  try {
    const { username } = req.params;
    const user = await User.findOne({ username: username.toLowerCase() })
      .populate('followers', 'username name')
      .populate('following', 'username name');
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json({
      id: user._id,
      name: user.name,
      username: user.username,
      bio: user.bio,
      avatar: user.avatar,
      followers: user.followers,
      following: user.following
    });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
};

export const follow = async (req, res) => {
  try {
    const targetUsername = req.params.username.toLowerCase();
    if (targetUsername === req.user.username) return res.status(400).json({ message: 'Cannot follow yourself' });
    const target = await User.findOne({ username: targetUsername });
    if (!target) return res.status(404).json({ message: 'User not found' });
    const me = await User.findById(req.user._id);
    if (me.following.includes(target._id)) return res.status(400).json({ message: 'Already following' });
    me.following.push(target._id);
    target.followers.push(me._id);
    await me.save();
    await target.save();
    res.json({ message: 'followed' });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
};

export const unfollow = async (req, res) => {
  try {
    const target = await User.findOne({ username: req.params.username.toLowerCase() });
    if (!target) return res.status(404).json({ message: 'User not found' });
    const me = await User.findById(req.user._id);
    me.following = me.following.filter(id => id.toString() !== target._id.toString());
    target.followers = target.followers.filter(id => id.toString() !== me._id.toString());
    await me.save();
    await target.save();
    res.json({ message: 'unfollowed' });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
};
