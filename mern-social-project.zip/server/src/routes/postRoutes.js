import { Router } from 'express';
import multer from 'multer';
import path from 'path';
import crypto from 'crypto';
import { authRequired } from '../middleware/auth.js';
import { createPost, getPost, likePost, unlikePost, addComment, feed } from '../controllers/postController.js';

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/')
  },
  filename: function (req, file, cb) {
    const ext = path.extname(file.originalname);
    cb(null, crypto.randomBytes(10).toString('hex') + ext);
  }
})
const upload = multer({ storage });

const router = Router();

router.get('/feed', authRequired, feed);
router.post('/', authRequired, upload.single('image'), createPost);
router.get('/:id', getPost);
router.post('/:id/like', authRequired, likePost);
router.post('/:id/unlike', authRequired, unlikePost);
router.post('/:id/comments', authRequired, addComment);

export default router;
