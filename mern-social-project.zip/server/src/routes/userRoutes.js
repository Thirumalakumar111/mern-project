import { Router } from 'express';
import { getProfile, follow, unfollow } from '../controllers/userController.js';
import { authRequired } from '../middleware/auth.js';

const router = Router();

router.get('/:username', getProfile);
router.post('/:username/follow', authRequired, follow);
router.post('/:username/unfollow', authRequired, unfollow);

export default router;
