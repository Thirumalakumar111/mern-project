# MERN Social — Server

### Quick Start
1) Copy `.env.example` to `.env` and set values.
2) `npm install`
3) `npm run dev`

### Endpoints (prefix: `/api`)
- `POST /auth/register` {name, username, email, password}
- `POST /auth/login` {emailOrUsername, password}
- `GET /auth/me` (auth)
- `POST /auth/logout`

- `GET /users/:username` public profile
- `POST /users/:username/follow` (auth)
- `POST /users/:username/unfollow` (auth)

- `GET /posts/feed` (auth) — posts by you and people you follow
- `POST /posts` (auth, multipart) — fields: `text`, optional file `image`
- `GET /posts/:id` public
- `POST /posts/:id/like` (auth)
- `POST /posts/:id/unlike` (auth)
- `POST /posts/:id/comments` (auth) {text}
